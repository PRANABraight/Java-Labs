public class ProgrammingCourse extends Course {
    public ProgrammingCourse() {
        super("Programming Fundamentals", 100.00);
    }

    @Override
    public void getCourseDetails() {
        System.out.println("Programming Course: " + getTitle() + " Price: $" + getPrice());
    }
}

class DataScienceCourse extends Course {
    public DataScienceCourse() {
        super("Data Science Bootcamp", 150.00);
    }

    @Override
    public void getCourseDetails() {
        System.out.println("Data Science Course: " + getTitle() + " Price: $" + getPrice());
    }
}

class WebDevelopmentCourse extends Course {
    public WebDevelopmentCourse() {
        super("Web Development Mastery", 120.00);
    }

    @Override
    public void getCourseDetails() {
        System.out.println("Web Development Course: " + getTitle() + " Price: $" + getPrice());
    }
}
 
