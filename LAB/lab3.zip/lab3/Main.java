import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input and Validation for Programming Course
        try {
            System.out.print("Enter the course name: ");
            String courseName = scanner.nextLine().trim();

            System.out.print("Enter the course code: ");
            String courseCode = scanner.nextLine().trim();

            System.out.print("Enter the programming language: ");
            String language = scanner.nextLine().trim();

            ProgrammingCourse javaCourse = new ProgrammingCourse(courseName, courseCode, language);
            javaCourse.addCourseDetail("Learn the basics of Java.")
                      .addCourseDetail("Object-oriented programming concepts.")
                      .addCourseDetail("Advanced Java topics.");

            javaCourse.displayCourseInfo();
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating programming course: " + e.getMessage());
        }

        System.out.println();

        // Input and Validation for Test Preparation Course
        try {
            System.out.print("Enter the test preparation course name: ");
            String testCourseName = scanner.nextLine().trim();

            System.out.print("Enter the course code: ");
            String testCourseCode = scanner.nextLine().trim();

            System.out.print("Enter the test type: ");
            String testType = scanner.nextLine().trim();

            TestPreparationCourse ieltsCourse = new TestPreparationCourse(testCourseName, testCourseCode, testType);
            ieltsCourse.addToDescription("Prepare for the "+ testType+" test.");

            ieltsCourse.displayCourseInfo();
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating test preparation course: " + e.getMessage());
        }

        // Closing the scanner
        scanner.close();
    }
}
