abstract class Course {
    protected String courseName;
    protected final String courseCode; // Final variable for course code
    protected StringBuilder courseDescription;

    // Constructor with validation for course name and course code
    public Course(String courseName, String courseCode) {
        if (courseName == null || courseName.trim().isEmpty()) {
            throw new IllegalArgumentException("Course name cannot be empty or null");
        }
        if (courseCode == null || courseCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code cannot be empty or null");
        }
        
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.courseDescription = new StringBuilder();
    }

    // Abstract method to be implemented by subclasses
    public abstract void displayCourseInfo();

    // Method to add to the course description with validation
    public void addToDescription(String detail) {
        if (detail == null || detail.trim().isEmpty()) {
            throw new IllegalArgumentException("Description detail cannot be empty or null");
        }
        courseDescription.append(detail).append(" ");
    }

    // Getter for course description
    public String getCourseDescription() {
        return courseDescription.toString().trim(); // Trimming trailing whitespace
    }
}
class ProgrammingCourse extends Course {
    private String language;

    // Constructor with validation for language
    public ProgrammingCourse(String courseName, String courseCode, String language) {
        super(courseName, courseCode);
        if (language == null || language.trim().isEmpty()) {
            throw new IllegalArgumentException("Language cannot be empty or null");
        }
        this.language = language;
    }

    // Overridden method to display course information
    @Override
    public void displayCourseInfo() {
        System.out.println("Programming Course: " + courseName + " [" + courseCode + "]");
        System.out.println("Language: " + language);
        System.out.println("Description: " + getCourseDescription());
    }

    // Method for method chaining with validation for detail
    public ProgrammingCourse addCourseDetail(String detail) {
        addToDescription(detail); // Uses validation in addToDescription
        return this; // Returns the current object for method chaining
    }
}
final class TestPreparationCourse extends Course {
    private String testType;

    // Constructor with validation for test type
    public TestPreparationCourse(String courseName, String courseCode, String testType) {
        super(courseName, courseCode);
        if (testType == null || testType.trim().isEmpty()) {
            throw new IllegalArgumentException("Test type cannot be empty or null");
        }
        this.testType = testType;
    }

    // Overridden method to display course information
    @Override
    public void displayCourseInfo() {
        System.out.println("Test Preparation Course: " + courseName + " [" + courseCode + "]");
        System.out.println("Test Type: " + testType);
        System.out.println("Description: " + getCourseDescription());
    }
}
