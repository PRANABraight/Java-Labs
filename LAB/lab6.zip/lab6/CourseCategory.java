
enum CourseCategory {
    PROGRAMMING,
    DATA_SCIENCE,
    WEB_DEVELOPMENT,
    DESIGN,

    BUSINESS
}

