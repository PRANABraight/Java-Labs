package com.elearning.course;

public interface Course {
    void addCourseDetail(String detail);
    void displayCourseInfo();
    String getCourseDescription();
    String getCourseName();
    String getCourseCode();
}
