import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class ElearningDemo {
    public static void main(String[] args) {
        Course course = new Course("Java Programming");
        List<Student> students = new ArrayList<>();
        Scanner scanner= new Scanner(System.in);
        System.out.println("Name: ");
        String name= scanner.nextLine();
        System.out.println("Use synchronisation: ");
        boolean bolVal=scanner.nextBoolean();

        students.add(new Student(course, "Alice", true));
        students.add(new Student(course, "Bob", true));
        students.add(new Student(course, "Charlie", true));
        students.add(new Student(course, "Dave", false));
        students.add(new Student(course, "Eve", false));
        students.add(new Student(course, name, bolVal));


        Thread waiter = new Thread(() -> {
            synchronized (course) {
                try {
                    System.out.println("Main thread is waiting for enrollment to complete...");
                    course.wait(3000); // Wait for 3 seconds
                } catch (InterruptedException e) {
                    System.out.println("Main thread interrupted while waiting.");
                }
                System.out.println("Main thread resumed.");
            }
        });

        waiter.start();
        students.forEach(Thread::start);

        try {
            synchronized (course) {
                Thread.sleep(2000);
                System.out.println("Main thread notifying all waiting threads...");
                course.notifyAll();
            }
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }

        // Wait for all threads to finish
        students.forEach(student -> {
            try {
                student.join();
            } catch (InterruptedException e) {
                System.out.println("Main thread interrupted while joining.");
            }
        });

        System.out.println("Enrollment process completed. Enrolled students:");
        course.getEnrolledStudents().forEach(System.out::println);
    }
}