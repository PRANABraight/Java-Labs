class Student extends Thread {
    private final Course course;
    private final String studentName;
    private final boolean useSync;

    public Student(Course course, String studentName, boolean useSync) {
        this.course = course;
        this.studentName = studentName;
        this.useSync = useSync;
    }

    @Override
    public void run() {
        if (useSync) {
            course.enrollStudentSync(studentName);
        } else {
            course.enrollStudentNonSync(studentName);
        }
    }
}